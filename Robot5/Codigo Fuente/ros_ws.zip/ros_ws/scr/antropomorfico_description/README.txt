ANTROPOMORFICO 3DOF - ROS 2 Jazzy

Dimensiones principales:
- Altura columna: 0.22 m
- Brazo superior: 0.145 m
- Antebrazo: 0.14 m
- Base: 0.10 x 0.10 x 0.04 m

Articulaciones:
- J1: revoluta sobre Z
- J2: revoluta sobre Y
- J3: revoluta sobre Y

Uso:
1) Copiar la carpeta antropomorfico_description dentro de ~/ros2_ws/src/
2) cd ~/ros2_ws
3) colcon build --symlink-install
4) source install/setup.bash
5) ros2 launch antropomorfico_description display.launch.py

En RViz:
- Fixed Frame: base_link
- Add -> RobotModel
- Description Source: Topic
- Description Topic: /robot_description

Modificar el URDF en:
~/ros2_ws/src/antropomorfico_description/urdf/antropomorfico_3DOF_modificado.urdf
Luego reconstruir con colcon build --symlink-install.
